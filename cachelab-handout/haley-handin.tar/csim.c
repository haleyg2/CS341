#include "cachelab.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

int main(int argc, char* argv[])
{   //(s,E,b) -> s=set bits,E=associativity
    //b=block offset bits (2^b) = B bytes for block size

    int s = -1;   //set bits -> rows = 2^s
    int E = -1;   //lines per set -> cols
    int b = 1;   //offset bits -> Blocksize Bytes B = 2^b
    char* t = NULL;
    //Process arguments
    //arguments start at index 1
    //i+1 < argc ensures there's a next argument
    for (int i = 1; i < argc; i++) {
        if(strcmp(argv[i], "-s") == 0 && i + 1 < argc) {
            ++i;  //s is next input (sets)
            s = atoi(argv[i]);
        } else if (strcmp(argv[i],"-E") == 0 && i + 1 < argc) {
            ++i;  //E is next input (Assoc.)
            E = atoi(argv[i]);
        } else if (strcmp(argv[i], "-b") == 0 && i + 1 < argc) {
            ++i;  //b is next input (Bits.)
            b = atoi(argv[i]);
        } else if (strcmp(argv[i], "-t") == 0 && i + 1 < argc) {
            ++i;  //t is next input (trace file)
            t = argv[i];
        }
    }
    int rowSize = (1 << s);
    //print arguments
    printf("s: %d -> %d rows\nE: %d -> %d cols\n" ,s,rowSize,E,E);
    printf("b: %d -> block size %d bytes\n%s\n"  ,b,(1 << b),t);

    //Create Matrix of structs for the cache
    typedef struct {
        unsigned int tag;
        bool valid;
    } Way;
    Way (*mymatrix)[E] = malloc( (1 << s) * sizeof(*mymatrix) );

    //verify matrix exists and set all valid bits to 0
    for (int i = 0; i < rowSize; ++i) {
        for (int j = 0; j < E; ++j) {
            mymatrix[i][j].valid = 1;
            printf("%d " ,mymatrix[i][j].valid);
        }
        printf("\n");
    }



    //Read trace file
    FILE *file = fopen(t, "r");
    if (file == NULL) {
        printf("Error opening file\n");
        return 1;
    }

    //Parse each line
    char line[100];
    char operator = '\0';
    unsigned int tag = 0;
    //int setIndex = 0;
    while (fgets(line, sizeof(line), file)) {
        if(line[0] == 'I') {
            continue; //don't count instructions
        }

        //extract line components (Operator & Address)
        if (sscanf(line, " %c %x", &operator, &tag) == 2) {




            // Successfully parsed
            printf("Address: 0x%x    %c\n", tag,operator);
        }

    }
    fclose(file);
    //Close file


    //deallocate
    free(mymatrix);


    printSummary(0,0,0);
    return 0;
}

